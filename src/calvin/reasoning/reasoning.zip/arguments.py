import confidence
import evidence

class Argument:
    """
    This happy class represents a complete argument. It holds the collection of trees and can do 
    the obvious thing where it calculates its confidence and stuffs.
    """
    
    def __init__(self, conclusion, runRules):
        """
        Creates a new Argument object from a list of Rule objects that have been run and stuffs.
        """
        self.conclusion = conclusion
        #this is likely to be fixable.
        self.evidence = [rule.toEvidRule() for rule in runRules 
                         if rule.wasRun() and rule.getConfidence().isValid()]
        
        self.__setConfidence()

    def toEvidence(self):
        return evidence.Argument(self)
                               
    def __repr__(self):
        return 'Argument about ' + str(self.conclusion) + '\n ' + str(self.confidence)
        
    def __setConfidence(self):
        """
        set the confidence in this argument's conclusion
        """
        if len(self.evidence) == 0:
            #if there is no evidence of any kind for the argument, then
            #there we can't put a valid confidence on the argument, no?
            #print "okay, doing this..."
            self.confidence = confidence.Confidence(confidence.Match.nil, confidence.Quality.poor)
        else:
            self.confidence = confidence.combine([rule.confidence for rule 
                                                  in self.evidence if rule.confidence.isPro()],
                                                 [rule.confidence for rule
                                                  in self.evidence if not rule.confidence.isPro()])
        
    def getProEvid(self):
        return [rule for rule in self.evidence if rule.confidence.isPro()]
    
    def getConEvid(self):
        return [rule for rule in self.evidence if not rule.confidence.isPro()]
        
    def getConfidence(self):
        """
        Returns my happy confidence. Here for all kinds of good O-O reasons.
        """
        return self.confidence
    

        
        
        