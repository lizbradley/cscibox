#this module defines all my rules (right at the moment)
#eventually these may get split up, if they're too hard to deal with as one file :P

from rules import *
from conclusions import Conclusion
from confidence import *
from guards import *
import samples


def __minusFun(x, y):
    return x-y

def __plusFun(x, y):
    return x+y

def __mulFun(x, y):
    return x*y

__minusFun.userDisp = {'infix':True, 'display':'-'}
__plusFun.userDisp = {'infix':True, 'display':'+'}
__mulFun.userDisp = {'infix':True, 'display':'*'}


"""
Construction of a rule:

conclusion,
guard,
[list of rhs items]
rule quality (may be a tuple. if so, it is (quality if true, quality if false)
confidence template (may be missing)

Conclusions: conclusion name, [optional list of conclusion parameters]
Guards: information retrieval function (NOT function name), [function parameters],
        comparison value, optional comparison function (NOT function name)

rhs items:
Observation: function name (in observations.py), [function parameters]
Calculation: function name (in calculataion.py), [function parameters], variable name for rest of rule
Simulation: function name (in simulations.py), [function parameters], variable name for rest of rule (may be None)
Argument: conclusion name, [optional list of conclusion parameters]

if any function parameter is a tuple, it is interpreted as a function to be run. The first value
should be the function to run (NOT function name), the second value should be a tuple of parameters
to the function.
"""


#top-level conclusions
#no process
makeRule(Conclusion("no process"), None, 
         [Argument("ages line up")], 
         Quality.absolute)

#erosion
makeRule(Conclusion("erosion"), None, 
         [Simulation("isLinearGrowth", ["age"], None)], 
         Quality.good)

makeRule(Conclusion("erosion"), None, 
         [Calculation("calcMax", ["age"], "max age"), 
          Observation("gt", ["max age", 50000])], 
         Quality.poor)

makeRule(Conclusion("erosion"), None, 
         [Argument("visual erosion")], 
         Quality.okay)

makeRule(Conclusion("erosion"), None, 
         [Calculation("calcMaxSample", ["age"], "erosion choice"), 
          Argument("representative sample", ["erosion choice", "age"])], 
         Quality.poor)

makeRule(Conclusion("erosion"), None, 
         [Calculation("calcMaxSample", ["age"], "erosion choice"), 
          Argument("acceptable sample", ["erosion choice"])], 
         (Quality.poor, Quality.absolute))

makeRule(Conclusion("erosion"), 
         Guard(samples.getLandformField, ["type"], "moraine"),
         [Observation("eqs", [(samples.getLandformField, ("type",)), "moraine"])],
         Quality.poor)

#inheritance
makeRule(Conclusion("inheritance"), None, 
         [Calculation("calcMean", ["ageUncertainty"], "meanErr"), 
          Argument("all within range", [(__minusFun, ("meanErr", 1000)), 
                                        (__plusFun, ("meanErr", 1000)), "ageUncertainty"])], 
         Quality.poor, Template(increment=-1, flip=True))

makeRule(Conclusion("inheritance"), None, 
         [Calculation("calcMinSample", ["age"], "inheritance choice"), 
          Argument("representative sample", ["inheritance choice", "age"])], 
         Quality.poor)

makeRule(Conclusion("inheritance"), None, 
         [Calculation("calcMinSample", ["age"], "inheritance choice"), 
          Argument("acceptable sample", ["inheritance choice"])], 
         (Quality.poor, Quality.absolute))

makeRule(Conclusion("inheritance"), None, 
         [Simulation("inheritanceShaped", [], None)], 
         Quality.good)

makeRule(Conclusion("inheritance"), 
         Guard(samples.getLandformField, ["type"], "moraine"),
         [Observation("eqs", [(samples.getLandformField, ("type",)), "moraine"])],
         Quality.poor)

makeRule(Conclusion("inheritance"),
         Guard(samples.getLandformField, ["type"], "lava flow"),
         [Observation("eqs", [(samples.getLandformField, ("type",)), "lava flow"])],
         Quality.good, Template(flip=True))

makeRule(Conclusion("inheritance"), None,
         [Simulation("inheritanceOkay", [], None)],
         (Quality.poor, Quality.absolute))

#snow cover
makeRule(Conclusion("snow cover"), None,
         [Simulation("isTrend", ["age", "boulder size", +1], None)],
         (Quality.good, Quality.okay), Template(increment=-1))

makeRule(Conclusion("snow cover"), 
         Guard(findRange, ["elevation"], 1500, lambda x, y: x > y), 
         [Simulation("isTrend", ["elevation", "age", -1], None)], 
         Quality.good)

makeRule(Conclusion("snow cover"), None, 
         [Calculation("calcMean", ["latitude"], "latitude"), 
          Calculation("calcMax", ["elevation"], "elevation"), 
          Argument("is cold", ["latitude", "elevation"])], 
         (Quality.poor, Quality.good))

#vegetation cover
makeRule(Conclusion("vegetation cover"), 
         Guard(findRange, ["elevation"], 500, lambda x, y: x > y), 
         [Simulation("isTrend", ["elevation", "age", +1], None)], 
         Quality.good)

#outlier
makeRule(Conclusion("outlier", ["sample"]), None, 
         [Argument("different origin", ["sample"])], 
         Quality.absolute)

makeRule(Conclusion("outlier", ["sample"]), None, 
         [Simulation("argueWithoutSample", ["sample", "no process"], None)], 
         (Quality.good, Quality.okay))

makeRule(Conclusion("outlier", ["sample"]), None, 
         [Simulation("skewsField", ["sample", "ageUncertainty"], None)], 
         Quality.good, Template(increment=-1))



#non-primary conclusions
makeRule(Conclusion("ages line up"), None, 
         [Simulation("checkOverlap", ['age', 'ageUncertainty'], None)], 
         Quality.absolute, Template(increment=1))

makeRule(Conclusion("all within range", ["bottom", "top", "field"]), None, 
         [Observation("forAll", ["gt", "field", "bottom"]), 
          Observation("forAll", ["lt", "field", "top"])], 
         Quality.absolute, Template(priority=True))

makeRule(Conclusion("is cold", ["latitude", "elevation"]), None, 
         [Observation("gt", ["elevation", 8000]), 
          Observation("gt", ["latitude", 15]),
          Observation("lt", ["latitude", -15])], 
         Quality.good)

makeRule(Conclusion("visual erosion"), 
         Guard(samples.getLandformField, ["type"], "moraine"), 
         [Observation("observed", [(samples.getLandformField, ("flat crested",))])], 
         Quality.good)

makeRule(Conclusion("visual erosion"), 
         Guard(samples.getLandformField, ["type"], "lava flow"), 
         [Observation("observed", [(samples.getLandformField, ("pitted",))])], 
         Quality.good)

makeRule(Conclusion("different origin", ["sample"]), 
         Guard(samples.getLandformField, ["type"], "moraine"), 
         [Observation("observed", [(samples.extractField, ("sample", "in matrix"))])], 
         Quality.okay, Template(flip=True))

makeRule(Conclusion("different origin", ["sample"]), None, 
         [Observation("observed", [(samples.extractField, ("sample", "bedrock"))])], 
         (Quality.absolute, Quality.poor), Template(flip=True))

makeRule(Conclusion("different origin", ["sample"]),
         #single source landform -> single chemical composition
         Guard(samples.getLandformField, ['type'], 'lava flow'), 
         [Simulation("differentChemistry", ["sample"], None)], 
         Quality.okay)

makeRule(Conclusion("representative sample", ["sample", "field"]), None, 
         [Simulation("skewsField", ["sample", "field"], None)], 
         Quality.good, Template(increment=-1, flip=True))

makeRule(Conclusion("acceptable sample", ["sample"]), None, 
         [Observation("gt", [(samples.extractField, ("sample", "age")), 
                             (samples.getLandformField, ("minimum age",))]), 
          Observation("lt", [(samples.extractField, ("sample", "age")), 
                             (samples.getLandformField, ("maximum age",))])], 
         Quality.absolute, Template(priority=True))
    



