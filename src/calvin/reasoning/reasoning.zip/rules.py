import types


import engine
import conclusions
import calculations
import observations
import simulations
import confidence
import evidence
import samples

ruleList = []

def makeRule(conclusion, prereqList, rhsList, quality, conftemplate = confidence.Template()):
    """
    Adds a new rule to the list of rules the system knows about.
    """
    ruleList.append(Rule(conclusion, prereqList, rhsList, quality, conftemplate))
    
def getRules(conclusion):
    """
    Returns the list of all rules with the appropriate conclusion name and number of arguments
    """
    return [rule for rule in ruleList if rule.conclusion == conclusion]



class RightHandSide:
    """
    Base class for the rhses in rule Horn clauses. Contains all the stuff that applies to everyone.
    
    This class is abstract.
    """
    def __init__(self, name, params = None, module = None):
        """
        name is the name of the function/argument used by this RHS. Should be a string.
        params is a list of strings/values that should be sent to the function (or added to the
          argument conclusion) when this RHS is "run"
        """
        self.name = name
        self.params = params
        self.module = module
        self.confidence = None
        
    def __repr__(self):
        return "RHS: runs function " + self.__class__.__name__ + "." + self.name
            
    def run(self, env):
        """
        "runs" this RHS appropriately and then sets the confidence. env should be the current,
        rule-local environment. Items in params will be replaced before running this RHS.
        """
        raise NotImplementedError("RightHandSide is an abstract class and should not be instantiated")
        
    def _useEnv(self, env):
        """
        updates this RHS's parameters to replace items in the environment with their values
        
        env should be a dictionary.
        """
        self.useParams = self.__convParams(env, self.params)
        
    def __convParams(self, env, paramList):
        #this handles the "normal" case where parameters just need to be replaced as well as the
        #"special" case where the parameter is actually a function call meant to be executed as this
        #rhs is being run. Could probably be done as a list comprehension but would be unreadable.
        
        if paramList is None:
            return None
        
        tmp = []
        for param in paramList:
            if type(param) == types.TupleType:
                val = param[0](*self.__convParams(env, param[1]))
            else:
                val = param not in env and param or env[param]
        
            tmp.append(val)
    
        return tmp
        
    def _callFunction(self, env):
        """
        calls the function defined by name with this RHS's parameter list. Returns any value returned
        by the function.
        """
        
        try:
            self._useEnv(env)
            rslt = getattr(self.module, self.name)(*self.useParams)
            return rslt
        except KeyError:
            #just make sure that confidence is None when I don't have any
            #input data, as it should be...
            self.confidence = None
            return False
        
    def toEvidence(self):
        """
        after this RHS has been 'run', returns a static evidence object holding
        the information to display the run rhs to the user
        """
        raise NotImplementedError("RightHandSide is an abstract class and should not be instantiated")
        
class ValuedRightHandSide(RightHandSide):
    """
    Base class for rhses that do return a value (calculations and simulations)
    
    This class is abstract.
    """
    
    def __init__(self, name, params, varName, module = None):
        RightHandSide.__init__(self, name, params, module)
        self.varName = varName


class UnvaluedRightHandSide(RightHandSide):
    """
    Base class for rhses that do not return a value (observations and arguments)
    
    This class is abstract, and exists only for typing convenience.
    """

class Calculation(ValuedRightHandSide):
    """
    Calculation RHS
    """
    
    def __init__(self, name, params, varName):
        ValuedRightHandSide.__init__(self, name, params, varName, calculations)
        
    def run(self, env):
        """
        Calculations update the environment; they have no interesting confidence issues
        """
        self.value = self._callFunction(env)
        if self.value:
            env[self.varName] = self.value
            self.confidence = None
            
    def toEvidence(self):
        return evidence.Calculation(self)
            
    def __repr__(self):
        return self.varName + '=' + str(self.value)
        

class Observation(UnvaluedRightHandSide):
    """
    Observation RHS
    """
    def __init__(self, name, params):
        UnvaluedRightHandSide.__init__(self, name, params, observations)
        
    def __repr__(self):
        st = "observed: " + self.name + str(self.params)
        if not self.confidence.isPro():
            st = "not " + st
        return st
    
    def toEvidence(self):
        return evidence.Observation(self)
        
    def run(self, env):
        """
        Observations are super-duper simple and were different from other things in scheme because
        (for instance) they handled a for-all/there-exists type of iteration. I think that can
        be reasonably handled elsewhere, tho...
        """
        rslt = self._callFunction(env)
        if rslt:
            self.confidence = confidence.Confidence(rslt, confidence.Quality.absolute)
        
            
            

class Simulation(ValuedRightHandSide):
    """
    Simulation RHS
    """
    
    def __init__(self, name, params, varName):
        ValuedRightHandSide.__init__(self, name, params, varName, simulations)
        self.simResult = None
        
    def toEvidence(self):
        return evidence.Simulation(self)
        
    def __repr__(self):
        return str(self.simResult)
        
    def run(self, env):
        """
        Simulations are complicated. Let us assume they return some sort of SimResult object and
        work from there.
        """
        rslt = self._callFunction(env)
        if rslt:
            self.simResult = rslt
            if self.varName is not None:
                env[self.varName] = self.simResult.getValue()
            self.confidence = self.simResult.getConfidence()

class Argument(UnvaluedRightHandSide):
    """
    Argument RHS
    """
    
    def __repr__(self):
        return str(self.argument)
    
    def toEvidence(self):
        return evidence.Argument(self.argument, self.params)
    
    def run(self, env):
        """
        So this is different because we don't call some function and then do something with the
        result. Instead, we need to call the engine and construct a new, complete argument for the
        conclusion listed in name.
        """
        self._useEnv(env)
        self.argument = engine.buildArgument(conclusions.Conclusion(self.name, self.useParams))
        self.confidence = self.argument.getConfidence()
        
    def toList(self):
        return self.argument.toList()
        

class Rule:
    """
    Object that defines a complete rule (Horn clause/implication).
    contains the conclusion, any prerequisites, the rhses and the confidence combination information.
    """
    
    def __init__(self, conclusion, guard, rhsList, quality, confTemplate):
        """
        Makes a new rule.
        """
        self.conclusion = conclusion
        self.guard = guard
        self.rhsList = rhsList
        self.quality = quality
        self.confTemplate = confTemplate
        self.confidence = None
        self.ran = False
       
       
    def toEvidRule(self):
        return evidence.EvidRule(self)
        
    def canRun(self):
        """
        evaluates the prerequisites. Returns true if all prereqs are met.
        """
        
        #if we're checking this, it's because we're running the rule anew and stuff
        #so let's just fix this here issue right now.
        self.ran = False
        
        if self.guard is None:
            return True
        else:
            return self.guard.guardPassed()
        
    def wasRun(self):
        return self.ran
        
    
    def run(self, filledConc):
        """
        "runs" this rule by "running" all its RHSes (recursively, as appropriate)
        
        Possibly ought to return a confidence, or something...?
        """
        if not self.canRun():
            raise UnrunnableRule(self.conclusion.name)
        
        env = self.__buildEnv(filledConc)
    
        #rhses are explicitly run in order.
        for rhs in self.rhsList:
            rhs.run(env)
            
        
        if any([rhs.confidence for rhs in self.rhsList]):    
            #this rule is only interesting if at least some of its input data actually existed...
            self.__setConfidence()   
            self.ran = True
        
    def __setConfidence(self):
        """
        sets the confidence in this rule after it has been run. Used for efficiency purposes and
        stuff.
        """
        
        self.confidence = self.confTemplate.unify(self.quality, 
                                    [rhs.confidence for rhs in self.rhsList if rhs.confidence])
        
            
    def __buildEnv(self, filledConc):
        """
        builds the environment that the rule starts with, based on the rule's conclusion and the
        parameters filling that conclusion.
        """
        
        if (self.conclusion.paramList is None \
             or len(self.conclusion.paramList) == 0) \
             and filledConc.paramList is None:
            return {}
        if len(filledConc.paramList) != len(self.conclusion.paramList):
            raise ValueError("Attempt to use a rule with incorrect number of conclusion parameters")
        return dict(zip(self.conclusion.paramList, filledConc.paramList))
            
    def getConfidence(self):
        """
        Returns the confidence that this rule adds to the overall confidence in the conclusion of
        this rule.
        
        Should this be calculated on the fly or stored?
        """
        return self.confidence
    
class UnrunnableRule(Exception):
    """
    Raised when someone tries to run a rule that cannot, in fact, be run according to its
    prerequisites. Used so I don't get all confused-like
    """
    
    def __init__(self, conc):
        self.conc = conc
    
    def __str__(self):
        return "Cannot run rule with conclusion %s: prerequisites not met" % self.conc
    
    
    
    