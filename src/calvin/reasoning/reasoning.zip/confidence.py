import types

def combine(proConfs, conConfs):
    #this should really be a static method in Confidence
    """
    Takes a set of confidences for a conclusion as the complete sets of confidences in favor of the
    conclusion and the confidences against the conclusion and combines them in a hopefully sane
    way into a single confidence in the conclusion.
    
    These lists /are/ altered as part of this method!
    """
    
    #sort trees in some sane way (so that max quals are at the front)
    proConfs.sort(reverse = True)
    conConfs.sort(reverse = True)
    
    #check for either tree empty, if so, return the best from the other
    #both trees empty: return <sf, poor>
    if not conConfs:
        if proConfs:
            return proConfs[0]
        else:
            return Confidence(Match.sf, Quality.poor)
    elif not proConfs:
        return conConfs[0]
    
    #if one max qual is > other, return that one as the final conf
    max = proConfs[0].compareQuals(conConfs[0])
    if max:
        return max
    
    #make a combined version of the top 2 confidences and add it to the appropriate list
    comb = proConfs[0].combine(conConfs[0])
    if comb:
        if comb.isPro():
            proConfs.append(comb)
        else:
            conConfs.append(comb)
    
    #and now recurse without the top one in both lists
    return combine(proConfs[1:], conConfs[1:])
    

class Confidence:
    """
    This class implements all my happy confidence goodness.
    
    A Confidence object is conceptually a vector with a quality and a match judgement. Matches may
    be true or false and more or less extreme, quality ranges from poor to certain. Quality is more
    importnant than match when comparing two confidence values.
    """
    
    def __init__(self, match, qual):
        self.match = match
        self.qual = qual
        
    def __repr__(self):
        return str(self.match) + " match to " + str(self.qual) + " quality knowledge"
    
    def __cmp__(self, other):
        assert type(self) == type(other)
        rslt = cmp(self.qual, other.qual)
        if rslt == 0:
            return self.match.cmpMagnitude(other.match)
        return rslt
    
    def __add__(self, val):
        return Confidence(self.match + val, self.qual)
    
    def __sub__(self, val):
        return Confidence(self.match - val, self.qual)
    
    def __neg__(self):
        return Confidence(-self.match, self.qual)
    
    
    @staticmethod
    def _minReduce(conf, other):
        return Confidence(min(conf.match, other.match), min(conf.qual, other.qual))
    
    @staticmethod
    def _maxReduce(conf, other):
        return Confidence(max(conf.match, other.match), min(conf.qual, other.qual))
    
    def cmpMatch(self, other):
        """
        Comparison that operates as follows.
        1. Any true match is > any false match
        2. then, greater quality confidences > lesser quality
        3. then, comparison is match extremity based
        
        this is equivalent to condition 1 followed by
        normal confidence comparison.
        """
        assert type(self) == type(other)
        rslt = cmp(self.isPro(), other.isPro())
        if rslt == 0:
            return cmp(self, other)
        return rslt
    
    def isPro(self):
        return self.match.isTrue()
    
    def isValid(self):
        return self.match.isValid()
    
    def compareQuals(self, other):
        if self.qual > other.qual:
            return self
        elif self.qual < other.qual:
            return other
        else:
            return None
        
    def combine(self, other):
        assert self.qual == other.qual
        mtch = self.match.combine(other.match)
        
        if mtch:
            return Confidence(mtch, self.qual - 1)
        else:
            return None
    
    @staticmethod
    def getUnifier(priority):
        if priority:
            return Confidence._minReduce
        else:
            return Confidence._maxReduce
    
class Template:
    """
    confidence template class stores the options available to rules for internal confidence 
    unification and performs said unification for said rules
    """
    
    def __init__(self, increment = 0, flip = False, priority = False):
        """
        Constructor takes the following parameters:
        
        increment: whether and how much to change the "Match" value for the rule (default = 0)
        flip: whether to flip the value for the rule the other direction from the evidence 
              (default = False)
        priority: whether "True" or "False" values take priority. More specifically, whether the
                  minimum or maximum confidence from the individual items is taken, when more than
                  one item exists (default = False = min)
                  
        these are applied in the order:
        select one confidence based on priority
        flip if appropriate
        increment
        """
        self.increment = increment
        self.flip = flip
        self.priority = priority
        
    def unify(self, quality, confs):
        """
        Turns the set of confs in the rhses into a single conf for the whole rule.
        """
        confs = [conf for conf in confs if conf] #filter out Nones
        
        x = [str(con) for con in confs]
        
        if len(confs) > 0:
            conf = reduce(Confidence.getUnifier(self.priority), confs)
        else:
            conf = Confidence(Match.nil, Quality.poor)
        
        
        
        if type(quality) == types.TupleType:
            if conf.isPro():
                quality = quality[0]
            else:
                quality = quality[1]
                
        if conf.qual > quality:
            conf = Confidence(conf.match, quality)
            
        if self.flip:
            conf = -conf
        
        return conf + self.increment
    
    
        
        
class Match:
    """
    Stores the direction and extremity of a "match" to a rule. Matches can be falsified, compared, 
    and simple addition can be performed on them (Match + 1 makes a Match one more step toward true,
    assuming it is not already at the max).
    """
        
    class _Match:
        """
        internal "Match" class to hide the constructor for Match objects
        """
        
        levels = {0:"", 1:"somewhat", 2:"", 3:"very"}
        truths = {True:" true", False:" false", -1:" no"}
        
        def __init__(self, level, value):
            self.level = level
            self.truth = value
            
        def __repr__(self):
            return Match._Match.levels[self.level] + Match._Match.truths[self.truth]
        
        def __cmp__(self, other):
            assert type(self) == type(other)
            tcmp = cmp(self.truth, other.truth)
            if tcmp == 0:
                if self.truth:
                    return cmp(self.level, other.level)
                else:
                    return cmp(other.level, self.level)
            return tcmp
        
        #add and sub make any match more or less extreme. This may turn out to be wrong later
        def __add__(self, val):
            return Match._Match(self.__snap(self.level + val), self.truth)
        
        def __sub__(self, val):
            return Match._Match(self.__snap(self.level - val), self.truth)
        
        def __neg__(self):
            return Match._Match(self.level, not self.truth)
            
        def __snap(self, val):
            if val < 1:
                return 1
            elif val > 3:
                return 3
            else:
                return val
            
        def cmpMagnitude(self, other):
            assert type(self) == type(other)
            rslt = cmp(self.level, other.level)
            if rslt == 0:
                return cmp(self.truth, other.truth)
            return rslt
        
        def isTrue(self):
            return self.truth
        
        def isValid(self):
            return self.truth != -1
        
        def combine(self, other):
            assert self.truth != other.truth
            
            lvl = self.level - other.level
            if lvl > 0:
                return Match._Match(lvl, self.truth)
            elif lvl == 0:
                return None
            else: #lvl < 0
                return Match._Match(-lvl, other.truth)
            
        def getLevel(self):
            return self.level
                
    st = _Match(1, True)
    t  = _Match(2, True)
    vt = _Match(3, True)
    sf = _Match(1, False)
    f  = _Match(2, False)
    vf = _Match(3, False)
    
    nil = _Match(0, -1)
    
    RANKS = 6 # don't actually show 'nil' matches
    
        
class Quality:
    """
    Stores a quality judgement of knowledge. For a rule, this is the quality of the rule. For a
    derived conclusion, this is the lowest quality of any piece of knowledge used in deriving the
    conclusion. Arithmetic operations and comparisons are available.
    """
    
    class _Quality:
        """
        internal "Quality" class to hide the constructor for Quality objects
        """
        
        levels = {0:"poor", 1:"okay", 2:"good", 3:"definite"}
        
        def __init__(self, level):
            self.qual = level
            
        def __repr__(self):
            return Quality._Quality.levels[self.qual]
        
        def __cmp__(self, other):
            assert type(other) == type(self)
            return cmp(self.qual, other.qual)
        
        def __add__(self, val):
            return Quality._Quality(self.__snap(self.qual + val))
        
        def __sub__(self, val):
            return Quality._Quality(self.__snap(self.qual - val))
        
        def __snap(self, val):
            if val < 0:
                return 0
            elif val > 3:
                return 3
            else:
                return val
            
    poor = _Quality(0)
    okay = _Quality(1)
    good = _Quality(2)
    absolute = _Quality(3)
    
    RANKS = 4
    
    




