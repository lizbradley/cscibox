sampleList = []
landformData = {}

samplePoll = []
landformPoll = []

dataTypes = {'flat crested':'bool', 'pitted':'bool', 
             'minimum age':'num', 'maximum age':'num', 'bedrock':'bool',
             'in matrix':'bool', 'boulder size':'num', 'Al2O3':'num', 
             'B':'num', 'CO2':'num', 'CaO':'num', 'Cl':'num', 'Fe2O3':'num', 
             'Gd':'num', 'K2O':'num', 'MgO':'num', 'MnO':'num', 'Na2O':'num', 
             'P2O5':'num', 'SiO2':'num', 'Sm':'num', 'Th':'num', 'TiO2':'num', 
             'U':'num'}

def needData():
    return len(samplePoll) > 0 or len(landformPoll) > 0

def sampleMax(sampleA, sampleB, fld):
    if sampleA[fld] > sampleB[fld]:
        return sampleA
    else:
        return sampleB
    
def sampleMin(sampleA, sampleB, fld):
    if sampleA[fld] < sampleB[fld]:
        return sampleA
    else:
        return sampleB

def getLandformField(fld):
    try:
        return landformData[fld]
    except KeyError:
        if fld not in landformPoll:
            landformPoll.append(fld)
        raise KeyError()
    
def getSampleField(num, fld):
    return sampleList[num][fld]

def extractField(sample, fld):
    return sample[fld]

def getAllFlds(fld):
    return [sample[fld] for sample in sampleList]

getLandformField.userDisp = {'infix':False, 'display':'landform property'}
getSampleField.userDisp = {'infix':False, 'display':'sample property'}
extractField.userDisp = {'infix':False, 'display':'sample property'}

class CalvinSample:
    """
    This class is a wrapper around the ACE sample that lets me grab useful
    things from the user after the fact. Also prints prettily. Whee.
    """
    def __init__(self, aceSam):
        self.aceSam = aceSam
    
    def __repr__(self):
        return self.aceSam['id']
    
    def __getitem__(self, key):
        item = self.aceSam[key]
        if item is None or item == '':
            #we don't actually have a value for this item, so...
            if key not in samplePoll:
                #plan to poll for this info later
                samplePoll.append(key)
            #and raise the error for elsewhere
            raise KeyError()
        return self.__typeCast(item)
    
    def __setitem__(self, key, value):
        #should consider telling repoman about this here change thing
        self.aceSam.set("input", key, value)
    
    def __typeCast(self, item):
        try:
            return float(item)
        except (TypeError, ValueError):
            return item