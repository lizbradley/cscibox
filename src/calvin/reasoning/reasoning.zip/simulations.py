"""
Simulations live here. A simulation should always be defined as a function that returns a single
SimResult object.
"""

import confidence
import samples
import engine
import conclusions

import math
from scipy import stats

class SimResult:
    """
    Represents the result of the simulation. Eventually this will contain not only confidence
    and some sort of value stuff, but also things like how to display the simulation on the pretty
    user interface
    """
    
    def __init__(self, value, conf, simType, params, visDesc = ""):
        self.value = value
        
        self.confidence = conf
        self.simType = simType
        self.params = params
        self.visDesc = visDesc
        
    def getDisplayString(self):
        if self.confidence.isPro():
            return self.simType
        else:
            return 'not ' + self.simType
        
    def getValue(self):
        return self.value
    
    def getConfidence(self):
        return self.confidence

def __getTruth(tvals, value):
    """
    Returns a truth value from a range of truth values
    tvals should be a tuple containing the 5 dividing values between each of the truth value
    ranges, from most false to most true dividers
    """
    
    if value < tvals[0]:
        return confidence.Match.vf
    elif value < tvals[1]:
        return confidence.Match.f
    elif value < tvals[2]:
        return confidence.Match.sf
    elif value < tvals[3]:
        return confidence.Match.st
    elif value < tvals[4]:
        return confidence.Match.t
    else:
        return confidence.Match.vt
    
def __getQuality(sig):
    """
    Converts a measure of statistical significance into a measure of simulation
    quality. Significance is assumed to be from 0-1, with larger values indicating
    less significance.
    
    ranges (for now) are:
    absolute 0-.01
    good .01-.05
    okay .05-.1
    poor .1+
    """
    
    if sig > .1:
        return confidence.Quality.poor
    elif sig > .05:
        return confidence.Quality.okay
    elif sig > .01:
        return confidence.Quality.good
    else:
        return confidence.Quality.absolute
    

def isTrend(fldA, fldB, dir):
    """
    What this needs to do is identify whether there is some trend between fldA and fldB in the
    appropriate direction. If dir is positive, this is a direct correlation; if it is negative,
    it is an inverse correlation.
    """
    
    if dir > 0:
        eDir = "positive"
    else:
        eDir = "negative"

    correlation = stats.pearsonr(samples.getAllFlds(fldA), samples.getAllFlds(fldB))
    
    truth = __getTruth((-.1, .2, .5, .7, .85), correlation[0] * dir)
    quality = __getQuality(correlation[1] / 2)
    
    """
    visDesc = "Graph of " + fldA + " vs. " + fldB
    visDesc += "\nPoints are:\n"
    visDesc += "\n".join([str(tup) for tup in zip(samples.getAllFlds(fldA), samples.getAllFlds(fldB))])
    """
    visDesc = 'Correlation between ' + fldA + ' and ' + fldB + ': ' + str(correlation[0])
    visDesc += '\nStatistical significance: ' + str(correlation[1])
    
    return SimResult(None, confidence.Confidence(truth, quality),
                     "correlation between fields", [eDir, fldA, fldB], visDesc)

def isLinearGrowth(fld):
    """
    This function looks at how linearly fld grows. The closer it can come to a straight line that
    goes through all the values of fld (assuming even growth along the other axis), the higher th
    confidence.
    """
    
    fldList = samples.getAllFlds(fld)
    fldList.sort()
    
    line = stats.linregress(range(len(fldList)), fldList)
    
    #line[0] is slope
    #line[1] is intercept
    
    truth = __getTruth((.8, .85, .9, .95, .99), line[2])
    quality = __getQuality(line[3])
    
    """
    visDesc = "Graph of " + fld + " spaced out evenly, plus the best fit line"
    visDesc += "\npoints are:\n"
    visDesc += "\n".join([str(tup) for tup in zip(range(len(fldList)), fldList)])
    visDesc += "\nLine is slope " + str(line[0]) + " intercept " + str(line[1]) 
    """
    visDesc = 'Straight line with slope: ' + str(line[0]) + ' and intercept: ' + str(line[1])
    visDesc += '\nfits ' + fld + ' within ' + str(line[2])
    visDesc += '.\nStatistical significance: ' + str(line[3])
    
    return SimResult(None, confidence.Confidence(truth, quality), 
                     "linear growth", [fld], visDesc)
    


#calcium potassium chlorine
#%of cl36 from different targets: trend with age
#PCA PK Pn
#sounds like different chemistry might be a conclusion of its own?
#big difference for at least some elements
#look at range in real world; may be different for different minerals
#Cl all over the place
#vs pot and cal are usually within 50% of mean 
#SiO 20%


def differentChemistry(sample):
    """
    Checks whether this sample has noticeably different chemical composition from all the other
    samples.
    """
    
    chemAtts = ['Al2O3', 'B', 'CO2', 'CaO', 'Cl', 'Fe2O3', 'Gd', 'K2O', 'MgO', 
                'MnO', 'Na2O', 'P2O5', 'SiO2', 'Sm', 'Th', 'TiO2', 'U']
    
    visDesc = ""
    conf = confidence.Confidence(confidence.Match.vt, confidence.Quality.absolute)
    for att in chemAtts:
        try:
            result = skewsField(sample, att)
            visDesc += '\n' + att + "   " + result.visDesc
            if conf.cmpMatch(result.confidence) > 0:
                conf = result.confidence
        except KeyError:
            #we don't have this chemistry item; ignore and continue.
            pass
    
    if len(visDesc) == 0:
        #so for this case, we had no chemical data at all...
        raise KeyError()
        
    return SimResult(None, conf, "different chemical composition", [sample], visDesc)

def argueWithoutSample(sample, conclusion):
    """
    Builds an argument for conclusion (assumed to be passed in as a string, NOT a full conclusion
    (so no parameters can be attached to the conclusion, currently...), but this may change), after 
    removing the given sample from the dataset.
    """
    
    savedSamples = samples.sampleList[:]
    samples.sampleList.remove(sample)
    
    arg = engine.buildArgument(conclusions.Conclusion(conclusion))

    samples.sampleList = savedSamples
    
    visDesc = str(arg)
    
    return SimResult(None, arg.getConfidence(), 
                     "argue for " + conclusion + " without sample", [sample], visDesc)

def skewsField(sample, field):
    """
    Checks whether the value of field in the passed in sample is significantly different from the
    value of field for the rest of the samples under consideration.
    """
    #print samples.sampleList
    
    savedSamples = samples.sampleList[:]
    samples.sampleList.remove(sample)
    
    try:
        flds = samples.getAllFlds(field)
    
        mean = stats.mean(flds)
        stddev = stats.std(flds)
        val = sample[field]
        
        devs = abs(val - mean) / stddev
    
    finally:
        #we should be fixing the sample list even when I crash!
        samples.sampleList = savedSamples
    
    truth = __getTruth((.2, .5, 1, 1.5, 2, 4), devs)
    if len(samples.sampleList) < 5:
        qual = confidence.Quality.poor
    elif len(samples.sampleList) < 10:
        qual = confidence.Quality.okay
    else:
        qual = confidence.Quality.good
        
    """
    visDesc = "Chart of samples marked with mean (sans this one) and stddev"
    visDesc += "\nand with this one and its distance from the mean marked out"
    visDesc += "\nmean = " + str(mean) + " and stddev = " + str(stddev) + " and val = " + str(val)
    """
    visDesc = 'Sample ' + str(sample) + ' is ' + str(devs) + ' standard deviations away from mean.'
    visDesc += '\nMean: ' + str(mean) + '\nStd dev: ' + str(stddev)
    visDesc += '\nSample value: ' + str(val)
    
    return SimResult(None, confidence.Confidence(truth, qual), 
                     "significantly different value in field", [field, sample], visDesc)

def inheritanceShaped():
    """
    Checks whether we can remove only a small percentage of samples from the oldest end of the 
    sample set and, in so doing, get a successful "no process" argument.
    """
    
    #first let's check that we need to remove samples
    conf = engine.buildArgument(conclusions.Conclusion("no process")).getConfidence()
    
    if conf.isPro() and conf.qual >= confidence.Quality.good:
        return SimResult(None, -conf, "required to remove samples to have good argument for no process", [])
    
    savedSamples = samples.sampleList[:]
    
    samples.sampleList.sort(cmp = lambda x, y: cmp(x["age"], y["age"]))
    
    while len(samples.sampleList) > 0:
        del samples.sampleList[-1]
        conf = engine.buildArgument(conclusions.Conclusion("no process")).getConfidence()
        if conf.isPro() and conf.qual >= confidence.Quality.good:
            break
    
    reduction = len(samples.sampleList) / float(len(savedSamples))
    samples.sampleList = savedSamples
        
    visDesc = "must remove older samples until " + str(len(samples.sampleList))
    visDesc += "\nremain to have good argument for no process (" + str(reduction) + "%)."
    
    truth = __getTruth((.25, .4, .5, .65, .85), reduction)
    
    return SimResult(None, confidence.Confidence(truth, confidence.Quality.absolute), 
                     "removing older samples fixes ages", [], visDesc)

def inheritanceOkay():
    """
    Checks that the amount of inheritance necesary for that cause to explain this sample set does
    not violoate the theoretical (mathematical) limits on the allowable amount of inheritance.
    """
    
    return SimResult(None, confidence.Confidence(confidence.Match.t, confidence.Quality.good), 
                     "valid by constraints on maximum inheritance", [], "give numbers here...")
    
def checkOverlap(anchor, spread):
    """
    Checks that every sample overlaps with every other sample at at least one point 
    in anchor/spread (or spread * 2)
    """
    
    range = [0, samples.sampleList[0][anchor] + samples.sampleList[0][spread]]
    range2 = [0, samples.sampleList[0][anchor] + 2 * samples.sampleList[0][spread]]
    
    for sample in samples.sampleList:
        sAnch = sample[anchor]
        sSpre = sample[spread]
        
        range[0] = max(range[0], sAnch-sSpre)
        range[1] = min(range[1], sAnch+sSpre)
        range2[0] = max(range2[0], sAnch-2*sSpre)
        range2[1] = min(range2[1], sAnch+2*sSpre)
        
    if range[1] > range[0]:
        dif = abs(range[1] - range[0]) / float(range[0] + range[1])
        qual = dif >= .05 and confidence.Quality.absolute or confidence.Quality.good
        desc = 'Samples within 1 sigma'
        desc += '\nOverlap is from ' + str(range[0]) + ' to ' + str(range[1])
        conf = confidence.Confidence(confidence.Match.t, qual)
    elif range2[1] > range2[0]:
        dif = abs(range2[1] - range2[0]) / float(range2[0] + range2[1])
        qual = dif >= .1 and confidence.Quality.okay or confidence.Quality.poor
        desc = 'Samples within 2 sigma'
        desc += '\nOverlap is from ' + str(range2[0]) + ' to ' + str(range2[1])
        conf = confidence.Confidence(confidence.Match.t, qual)
    else:
        dif = abs(range2[1] - range2[0]) / float(range2[0] + range2[1])
        desc = 'Samples do not overlap within 2 sigma'
        desc += '\nGap is from ' + str(range2[1]) + ' to ' + str(range2[0])
        
        if dif > .2:
            qual = confidence.Quality.absolute
        elif dif > .1:
            qual = confidence.Quality.good
        elif dif > .02:
            qual = confidence.Quality.okay
        else:
            qual = confidence.Quality.poor
        conf = confidence.Confidence(confidence.Match.f, qual)
        
    return SimResult(None, conf, 'sample ' + anchor + ' plus or minus ' 
                     + spread + ' overlaps for all samples', [], desc)
    
    
    
    
    
    




