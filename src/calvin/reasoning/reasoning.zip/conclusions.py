import confidence
import samples

__NO_PARAM = 0
__ALL_SAMPLES = 1

curState = 0
highConf = confidence.Confidence(confidence.Match.t, confidence.Quality.good)

conclusions = [[("no process", __NO_PARAM), ("erosion", __NO_PARAM), ("inheritance", __NO_PARAM)],
               [("vegetation cover", __NO_PARAM), ("snow cover", __NO_PARAM)],
               [("outlier", __ALL_SAMPLES)]]

def finished(confList = None):
    """
    tells the engine if it's done yet :)
    """
    
    if confList == None or curState == 0:
        return False
    elif curState == len(conclusions):
        return True
    else:
        return any([conf >= highConf for conf in confList if conf.isPro()])
    
def canContinue():
    """
    Are there any more conclusions in existence to argue about?
    """
    
    return curState < len(conclusions)
    
def reset():
    """
    Resets the conclusion state for starting up a new set of samples.
    Call this in between each thingymajig
    """
    global curState
    curState = 0

def getNextConclusions():
    """
    this function returns the list of conclusions that the engine should argue about next. All
    parameters should be pre-entered.
    """
    global curState
    tupleList = conclusions[curState]
    concList = []
    for name, type in tupleList:
        concList.extend(__fillParams(name, type))
    curState += 1
    return concList
    
def __fillParams(name, type):
    """
    fills in parameters for conclusions and then returns the appropriate list of conclusion objects 
    based on the type ID passed in.
    """
    
    if type == __NO_PARAM:
        return [Conclusion(name, None)]
    if type == __ALL_SAMPLES:
        return [Conclusion(name, [sample]) for sample in samples.sampleList]

class Conclusion:
    """
    Contains the symbol (name) of a specific instance of a conclusion plus the list of arguments
    applicable to this specific conclusion (like outlier x).
    
    Also represents the same thing but with arguments filled in (like outlier 2)
    """
    def __init__(self, name, paramList = None):
        self.name = name
        self.paramList = paramList
        if paramList is not None and len(paramList) == 0:
            self.paramList = None
        
    def __eq__(self, other):
        if isinstance(other, Conclusion):
            return self.name == other.name and \
                (self.paramList is None and other.paramList is None or \
                len(self.paramList) == len(other.paramList))
        else:
            return False
        
    def __repr__(self):
        st = self.name
        if self.paramList is not None:
            st += ' (' + ', '.join([str(param) for param in self.paramList]) + ')'
        return st
        
    

        