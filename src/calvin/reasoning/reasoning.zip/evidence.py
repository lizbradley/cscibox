import types
import observations

#so in a perfect world I would have a spiffy little dictionary of function
#names in code vs. how they should be displayed to the user. Not gonna
#do that right this second, but keep it in mind for the nearish future

class Evidence:
    def __init__(self, rhs):
        self.name = rhs.name
        #self.env = rhs.useParams
        self.params = rhs.params
        self.confidence = rhs.confidence
        
    def __cmp__(self, other):
        return self.confidence.cmpMatch(other.confidence)
        
    #this could use some refactoring at some point...
    def _formatVar(self, var):
        if hasattr(var, '__iter__'):
            if hasattr(var[0], 'userDisp'):
                disp = var[0].userDisp
                if disp['infix']:
                    return str(var[1][0]) + ' ' + disp['display'] + ' ' + str(var[1][1])
                else:
                    return disp['display'] + ': ' + ', '.join([str(v) for v in var[1]])
            else:
                return var[0].func_name + str(var[1])
        else:
            return str(var)
        
    def _formatParams(self):
        if len(self.params) > 0:
            return ' (' + ', '.join([self._formatVar(var) for var in self.params]) + ')'
        else:
            return ""
        
        
    @classmethod
    def hasExpansion(cls):
        return False
    
    @classmethod
    def isArgument(cls):
        return cls.__name__ == "Argument"
    
    @classmethod
    def isSimulation(cls):
        return cls.__name__ == "Simulation"
        
    def getDisplayString(self):
        raise NotImplementedError("Evidence is an abstract class and should not be instantiated")
          

class Calculation(Evidence):
    
    def __init__(self, rhs):
        Evidence.__init__(self, rhs)
        self.varName = rhs.varName
        self.value = rhs.value
        
    def getDisplayString(self):
        return "set " + self.varName + " := " + str(self.value)
    
        
class Observation(Evidence):
    
    def __init__(self, rhs):
        Evidence.__init__(self, rhs)
    
    def getDisplayString(self):
        if self.confidence is None:
            return "Input Data Missing"
        nStr = ""
        if not self.confidence.isPro():
            nStr = 'not '
        return nStr + self.__strParams(self.name, self.params)
    
    def __strParams(self, nm, prms):
        if nm in observations.allSamples:
            return nm + " samples " + self.__strParams(prms[0], prms[1:])
        elif observations.binaries.has_key(nm):
            #fix this so values are included with prms[x]
            #and functiony thingy bits are purty-like
            return self._formatVar(prms[0]) + observations.binaries[nm] + self._formatVar(prms[1])
        else:
            return self._formatVar(prms[0])

class Simulation(Evidence):
    def __init__(self, sim):
        Evidence.__init__(self, sim)
        self.result = sim.simResult
        
        self.params = self.result.params
        self.visDesc = self.result.visDesc
        
        if sim.varName is not None:
            self.varName = sim.varName
            self.value = sim.simResult.value
            
    def getDisplayString(self):
        return self.result.getDisplayString() + self._formatParams()
    
    @classmethod
    def hasExpansion(cls):
        return True

class Argument(Evidence):
    def __init__(self, arg, params=None):
        self.conclusion = arg.conclusion
        self.params = params
        self.confidence = arg.confidence
        self.evidence = arg.evidence
        self.guiItem = None
        #print self.evidence
        
    def getDisplayString(self):
        #fix this so I do something more useful with my parameters
        return 'Argument about ' + self.getConclusionString()
    
    def getTitleString(self):
        return 'Argument about ' + self.getConclusionString() + '\n ' + str(self.confidence)
    
    def getConclusionString(self):
        if self.params is not None:
            return self.conclusion.name + self._formatParams()
        else:
            #no named parameters cuz of the whole thingy-thing
            #fix dis for purtyness
            return str(self.conclusion)
        
    def getProEvid(self):
        return [rule for rule in self.evidence if rule.confidence.isPro()]
    
    def getConEvid(self):
        return [rule for rule in self.evidence if not rule.confidence.isPro()]
    
    def setGUIItem(self, guiItem):
        """
        Lets me store the GUI thingy created for this argument so I can get
        it back later
        """
        self.guiItem = guiItem
        
    def getGUIItem(self):
        """
        Get the stored GUI thingy back, or None
        """
        
        return self.guiItem
    
    @classmethod
    def hasExpansion(cls):
        return True

class EvidRule:
    def __init__(self, rule):
        self.conclusion = rule.conclusion
        self.rhsList = [rhs.toEvidence() for rhs in rule.rhsList]
        self.confidence = rule.confidence
        
    def __cmp__(self, other):
        assert type(self) == type(other)
        return cmp(self.confidence, other.confidence)
    
    def __repr__(self):
        return "; ".join([rhs.getDisplayString() for rhs in self.rhsList])
        

