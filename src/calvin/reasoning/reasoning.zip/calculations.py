#this module contains all the functions that do various sorts of calculations...
import samples

def calcMean(fName):
    #well, this is pretty obvious
    #sum the values for all samples in fName and then divide by # of samples
    #print "calcing mean..."
    #x = samples.getAllFlds(fName)
    #print x
    sum = reduce(lambda x, y: x + y, samples.getAllFlds(fName), 0)
    #print sum, len(samples.sampleList)
    res = sum / len(samples.sampleList)
    #print "res = " + str(res)
    return res


def calcMax(fName):
    #this direction is cheaper: fewer iterations over a list
    return calcMaxSample(fName)[fName]

def calcMin(fName):
    #this direction is cheaper: fewer iterations over a list
    return calcMinSample(fName)[fName]

def calcMaxSample(fName):
    """
    Just like calcMax but returns a sample, not a value.
    """
    return reduce(lambda x, y: samples.sampleMax(x, y, fName), samples.sampleList)

def calcMinSample(fName):
    """
    Just like calcMin but returns a sample, not a value.
    """
    return reduce(lambda x, y: samples.sampleMin(x, y, fName), samples.sampleList)