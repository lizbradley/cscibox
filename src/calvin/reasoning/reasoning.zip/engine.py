import rule_list
import rules
import conclusions
import arguments
import samples


def explainAges():
    """
    Attempts to explain ages and stuff.
    """
    lastConf = None
    
    res = []
    while not conclusions.finished(lastConf):
        argList = [buildArgument(conclusion) for conclusion in conclusions.getNextConclusions()]
        lastConf = [arg.getConfidence() for arg in argList]
        
        res.extend([arg.toEvidence() for arg in argList])
        
    return res
    
def display(argList):
    for arg in argList:
        arg.display()
    
def buildArgument(conclusion):
    """
    builds an argument for the conclusion given. The conclusion should contain "filled" parameters,
    if it has any parameters.
    """
    
    ruleList = rules.getRules(conclusion)
    
    #list of rules might be long, let's try to avoid killing too much memory
    for rule in ruleList:
        try:
            if rule.canRun():
                rule.run(conclusion)
        except KeyError:
            """
            This fab error means we tried to do something with some data that the user didn't enter.
            We just silently fail for the moment. Frankly I think this is a much more elegant way to
            handle the issue I've been running into here.
            Also useful: later we can save these rules and use them to say something about what sort
            of new data might change our conclusions.
            """
            pass
    
    return arguments.Argument(conclusion, ruleList)
    
    