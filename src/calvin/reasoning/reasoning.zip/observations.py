#this module contains all the functions that do various sorts of simple things to observed data
import samples
import confidence

binaries = {"lt":' < ', "gt":' > ', "eqs":' = '}
allSamples = ["forAll"]

def __howDif(a, b):
    if a is None or b is None:
        raise KeyError()
    if type(a) == type("") or type(b) == type(""):
        #one of my variables never got resolved, so I'm missing
        #that piece of input data
        raise KeyError()
    #print a, b
    div = a + b
    percent = div != 0 and float(abs(a - b)) / div or 0
    
    if percent < .05:
        return confidence.Match.st
    elif percent < .1:
        return confidence.Match.t
    else:
        return confidence.Match.vt

def lt(a, b):
    dif = __howDif(a, b)
    return a < b and dif or -dif

def gt(a, b):
    dif = __howDif(a, b)
    return a > b and dif or -dif

def eqs(a, b):
    if a is None or b is None:
        raise samples.NoInputData()
    
    if a == b:
        return confidence.Match.t
    else:
        return confidence.Match.f

def observed(item):
    """
    checks whether the item was observed and, if so, returns whether it was observed in
    the positive or negative
    """ 
    if item is None or not item:
        return confidence.Match.f
    else:
        return confidence.Match.t

def forAll(fcn, fName, parms):
    """
    for every sample, applies fcn (passed as a string and in this module) to that sample's value
    for fName and whatever other value fcn takes (since everything here is a comparison, things
    always take 2 values...)
    """
    fun = globals()[fcn]
    
    val = min([fun(sample[fName], parms) for sample in samples.sampleList])
    return val
