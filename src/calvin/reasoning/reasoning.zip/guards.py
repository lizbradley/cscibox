"""
module for guards on rules. This is in its own module so that special-purpose functions for
guards can be defined here rather than cluttering up some other module.
"""


import samples

class Guard:
    """
    Represents the guard on a rule, determining whether it can run
    """
    
    def __init__(self, fetch, params, compare, 
                 comparison = lambda x,y: x == y):
        """
        Represents the guard on a rule. Requires the function to call to get the data to be
        checked, the parameters to that function, and what value the returned data is to be 
        compared to. Comparison is for equality by default, but other comparison functions
        may be passed instead. Order of call for these comparison functions is returned data,
        compare value.
        """
        self.fetch = fetch
        self.params = params
        self.compare = compare
        self.comparison = comparison
        
        
    def guardPassed(self):
        try:
            val = self.fetch(*self.params)
        except KeyError:
            return False
        
        return self.comparison(val, self.compare)
    
def findRange(fld):
    """
    finds the range of data over a field. That is, it finds the min and max of the field and
    then returns max - min.
    """
    vals = samples.getAllFlds(fld)
    return max(vals) - min(vals)